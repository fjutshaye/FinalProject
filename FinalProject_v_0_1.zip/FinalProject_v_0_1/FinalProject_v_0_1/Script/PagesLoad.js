﻿function includeNavigation() {
    document.write('\
<div class="nav_div">\
<ul class="nav_ul">\
<li class="nav_li"><a class="nav_a" href="../Pages/Page_Home.aspx">Home</a></li>\
<li class="nav_li"><a class="nav_a" href="../Pages/Page_Profile.aspx">Profile</a></li>\
<li class="nav_li"><a class="nav_a" href="">Carpool</a></li>\
<li class="nav_li"><a class="nav_a" href="../Pages/Page_PostRequest.aspx">Post Request</a></li>\
</ul>\
</div>\
    ')
}
function includeFooter() {
    document.write('\
<div class="footer_div">\
@Copyright Reserved by Jeremy\
</div>\
    ')
}
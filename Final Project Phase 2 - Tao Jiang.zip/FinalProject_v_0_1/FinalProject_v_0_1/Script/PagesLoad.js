﻿function includeNavigation() {
    document.write('\
<div class="nav_div">\
<ul class="nav_ul">\
<li class="nav_li"><a class="nav_a" href="../Pages/Page_Home.aspx">Home</a></li>\
<li class="nav_li"><a class="nav_a" href="../Pages/Page_Profile.aspx">Profile</a></li>\
<li class="nav_li"><a class="nav_a" href="">Carpool</a></li>\
<li class="nav_li"><a class="nav_a" href="">Post Request</a></li>\
</ul>\
</div>\
    ')
}